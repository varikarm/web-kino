package com.example.myapplication6;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class List1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list1);
    }

}
